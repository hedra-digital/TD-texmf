-- Config file for tex4ebook

-- Font config

Font{
  name   = "cmr",
  file   = "lmroman10-regular.otf",
  family = "Latin Modern",
  weight = "normal",
  style  = "normal"
}

Font{
  name   = "cmmi",
  file   = "lmroman10-italic.otf",
  family = "Latin Modern",
  weight = "normal",
  style  = "italic"
}
